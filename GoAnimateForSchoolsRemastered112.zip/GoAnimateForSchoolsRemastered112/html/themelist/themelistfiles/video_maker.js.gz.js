var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

(function(a){a(".theme-cell").each(function(){var b=a(".apps > .btn:first-child",this);a(".theme-cover",this).click(function(c){c.preventDefault();if(b.attr("href")!==undefined){window.location.href=b.attr("href")}else{b.trigger("click")}}).addClass("launch")});a(".themes .apps > .btn").tooltip()})(jQuery);

}
/*
     FILE ARCHIVED ON 23:07:38 Feb 06, 2019 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 21:00:24 Jun 06, 2020.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 11.619
  PetaboxLoader3.resolve: 854.932 (4)
  LoadShardBlock: 1482.257 (3)
  load_resource: 343.555
  esindex: 0.021
  exclusion.robots.policy: 0.284
  captures_list: 1525.778
  exclusion.robots: 0.305
  PetaboxLoader3.datanode: 939.445 (4)
  CDXLines.iter: 25.311 (3)
*/